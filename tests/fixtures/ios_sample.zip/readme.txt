Treska synthetic iOS FFS fixture.
