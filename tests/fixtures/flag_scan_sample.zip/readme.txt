Treska synthetic flag-scan fixture.
