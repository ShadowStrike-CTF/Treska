Treska test fixture.
