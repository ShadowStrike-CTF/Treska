Treska synthetic Android logical fixture.
